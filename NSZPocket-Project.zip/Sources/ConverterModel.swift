import Foundation
import Combine

// Progress from the native, bounded-memory C/Zstandard decompressor.
// On each callback we bounce to the main thread before changing UI state.
private final class ProgressRelay {
    weak var model: ConverterModel?
    init(_ model: ConverterModel) { self.model = model }
}

@MainActor
final class ConverterModel: ObservableObject {
    @Published var isConverting = false
    @Published var progress = 0.0
    @Published var status = "Choose a .nsz file from Files to begin."
    @Published var errorMessage: String?
    @Published var outputURL: URL?

    func convert(_ inputURL: URL) {
        guard !isConverting else { return }
        guard inputURL.pathExtension.lowercased() == "nsz" else {
            errorMessage = "Please select a .nsz file."
            return
        }

        let fileManager = FileManager.default
        guard let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else {
            errorMessage = "Cannot access the app's Documents folder."
            return
        }
        // The core exclusively creates its output and won't overwrite an existing NSP.
        // A UUID avoids collisions and preserves previous conversions.
        let base = inputURL.deletingPathExtension().lastPathComponent
        let name = base.isEmpty ? "Converted" : base
        let outputURL = documents.appendingPathComponent(name + "-" + UUID().uuidString.prefix(8) + ".nsp")

        isConverting = true
        progress = 0
        self.outputURL = nil
        status = "Decompressing \(inputURL.lastPathComponent)…"
        errorMessage = nil

        let relay = ProgressRelay(self)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let secured = inputURL.startAccessingSecurityScopedResource()
            defer { if secured { inputURL.stopAccessingSecurityScopedResource() } }

            let ptr = Unmanaged.passRetained(relay).toOpaque()
            defer { Unmanaged<ProgressRelay>.fromOpaque(ptr).release() }

            var message = [CChar](repeating: 0, count: 1024)
            let code: Int32 = inputURL.path.withCString { source in
                outputURL.path.withCString { target in
                    message.withUnsafeMutableBufferPointer { buffer in
                        nsz_convert(source, target, { written, total, context in
                            guard let context = context, total > 0 else { return }
                            let progress = min(1, Double(written) / Double(total))
                            let relay = Unmanaged<ProgressRelay>.fromOpaque(context).takeUnretainedValue()
                            DispatchQueue.main.async { [weak model = relay.model] in
                                model?.progress = progress
                            }
                        }, ptr, buffer.baseAddress, buffer.count)
                    }
                }
            }
            let failure = String(cString: message)

            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.isConverting = false
                if code == 0 {
                    self.progress = 1
                    self.outputURL = outputURL
                    self.status = "Conversion complete! Your NSP is ready to share or open in Files."
                } else {
                    self.outputURL = nil
                    self.status = "Conversion failed. The source NSZ was not modified."
                    self.errorMessage = failure.isEmpty ? "Unsupported or invalid NSZ file." : failure
                }
            }
        }
    }
}
