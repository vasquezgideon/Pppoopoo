#ifndef NSZCORE_H
#define NSZCORE_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Thread-safe; writes .nsp to outputPath, returns 0 on success. A partial output is deleted on error. */
typedef void (*nsz_progress_fn)(uint64_t written, uint64_t total, void *context);
int nsz_convert(const char *inputPath, const char *outputPath,
                nsz_progress_fn progress, void *context,
                char *errorMessage, size_t errorMessageSize);
#ifdef __cplusplus
}
#endif
#endif
