import SwiftUI
import UniformTypeIdentifiers

@main
struct NSZPocketApp: App {
    @StateObject private var converter = ConverterModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(converter)
        }
    }
}

struct ContentView: View {
    @EnvironmentObject private var converter: ConverterModel
    @State private var importPresented = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    Image(systemName: "archivebox.fill")
                        .font(.system(size: 46, weight: .semibold))
                        .foregroundStyle(.tint)
                        .frame(width: 98, height: 98)
                        .background(.tint.opacity(0.1), in: RoundedRectangle(cornerRadius: 27))
                        .padding(.top, 24)

                    VStack(spacing: 8) {
                        Text("NSZ → NSP")
                            .font(.largeTitle.bold())
                        Text("Decompress Switch NSZ files entirely on your iPhone. No upload, server, or system keys required for standard NSZ files.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }

                    VStack(alignment: .leading, spacing: 16) {
                        Label("Local conversion", systemImage: "iphone.gen3")
                            .font(.headline)
                        Text(converter.status)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)

                        if converter.isConverting {
                            ProgressView(value: converter.progress)
                                .tint(.accentColor)
                            Text("\(Int(converter.progress * 100))%")
                                .font(.system(.subheadline, design: .monospaced))
                                .foregroundStyle(.secondary)
                        }

                        Button {
                            importPresented = true
                        } label: {
                            Label(converter.isConverting ? "Converting…" : "Choose NSZ File", systemImage: "folder")
                                .frame(maxWidth: .infinity)
                                .font(.headline)
                                .padding(.vertical, 8)
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(converter.isConverting)

                        if let output = converter.outputURL {
                            ShareLink(item: output, preview: SharePreview(output.lastPathComponent)) {
                                Label("Share / Save NSP", systemImage: "square.and.arrow.up")
                                    .frame(maxWidth: .infinity)
                                    .font(.headline)
                                    .padding(.vertical, 8)
                            }
                            .buttonStyle(.bordered)
                            Text("Saved in Files → On My iPhone → NSZPocket")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20))

                    VStack(alignment: .leading, spacing: 9) {
                        Label("Before you convert", systemImage: "info.circle")
                            .font(.headline)
                        Text("Keep the app open while converting. You need enough free storage for the full NSP, which may be much larger than the NSZ. The original file is preserved.")
                        Text("Supports standard NSZ containers with solid or block-compressed NCZ data. XCZ and standalone NCZ are not supported in this version.")
                    }
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
            .navigationTitle("NSZPocket")
            .navigationBarTitleDisplayMode(.inline)
            .fileImporter(isPresented: $importPresented,
                          allowedContentTypes: [.item],
                          allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    if let url = urls.first { converter.convert(url) }
                case .failure(let error):
                    converter.status = "Unable to select file: \(error.localizedDescription)"
                }
            }
            .alert("Conversion failed", isPresented: Binding(
                get: { converter.errorMessage != nil },
                set: { if !$0 { converter.errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) { converter.errorMessage = nil }
            } message: {
                Text(converter.errorMessage ?? "Unknown error")
            }
        }
    }
}
