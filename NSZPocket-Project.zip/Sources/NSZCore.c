/* NSZPocket: streaming PFS0/NCZ -> NSP conversion.
   NSZ/NCZ format specification: https://github.com/nicoboss/nsz/blob/master/docs/formats.md
   No Switch system keys are needed: NCZ records carry re-encryption section keys.
   zstd: https://github.com/facebook/zstd (BSD OR GPL-2.0 license; BSD use here).
*/
#define _FILE_OFFSET_BITS 64
#include "NSZCore.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <limits.h>
#include <inttypes.h>
#include <fcntl.h>
#include <unistd.h>
#include "zstd.h"
#ifdef __APPLE__
#include <CommonCrypto/CommonCryptor.h>
#else
#include <openssl/evp.h>
#endif

#define CHUNK 65536u
#define MAX_HEADER (32u * 1024u * 1024u)
#define MAX_SECTIONS 65536u
#define MAX_BLOCK (32u * 1024u * 1024u)
#define MAX_FILES 100000u

static uint32_t le32(const unsigned char *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);
}
static uint64_t le64(const unsigned char *p) {
  return (uint64_t)le32(p) | ((uint64_t)le32(p+4)<<32);
}
static void put32(unsigned char *p, uint32_t x) { for(int i=0;i<4;i++)p[i]=(unsigned char)(x>>(i*8)); }
static void put64(unsigned char *p, uint64_t x) { for(int i=0;i<8;i++)p[i]=(unsigned char)(x>>(i*8)); }
static bool at(FILE *f, uint64_t off) { return off <= INT64_MAX && fseeko(f,(off_t)off,SEEK_SET)==0; }
static bool get(FILE *f, void *b, size_t n) { return fread(b,1,n,f)==n; }
static bool put(FILE *f, const void *b, size_t n) { return fwrite(b,1,n,f)==n; }
static bool add_ok(uint64_t a, uint64_t b, uint64_t *out) { if(UINT64_MAX-a<b)return false; *out=a+b;return true; }

struct Entry { uint64_t inOff,inSize,outSize; uint32_t nameOffset; bool compressed; };
struct Section { uint64_t off,size,crypto; unsigned char key[16],ctr[16]; };
struct Reader {
  FILE *f;
  uint64_t pos,end;
  bool block;
  ZSTD_DStream *ds;
  unsigned char inBuf[CHUNK],outBuf[CHUNK];
  size_t inPos,inSize,outPos,outSize;
  uint32_t *compressedSizes,blockCount,blockIndex;
  uint64_t totalUncompressed,blockSize;
  unsigned char *blockBuf;
  size_t blockPos,blockAvail;
};

static void reader_close(struct Reader *r){
  if(r->ds)ZSTD_freeDStream(r->ds);
  free(r->compressedSizes);free(r->blockBuf);
  memset(r,0,sizeof(*r));
}
static bool reader_init(struct Reader *r, FILE *f, uint64_t payloadStart, uint64_t fileEnd,
                        uint64_t uncompressedSize, char *err, size_t errLen){
  memset(r,0,sizeof(*r));r->f=f;r->end=fileEnd;r->pos=payloadStart;
  if(payloadStart>fileEnd || !at(f,payloadStart))return false;
  unsigned char magic[8]={0};
  if(fileEnd-payloadStart>=8 && !get(f,magic,8))return false;
  if(memcmp(magic,"NCZBLOCK",8)!=0){
    r->ds=ZSTD_createDStream();if(!r->ds)return false;
    if(ZSTD_isError(ZSTD_initDStream(r->ds)))return false;
    return at(f,payloadStart);
  }
  unsigned char bh[16];if(!get(f,bh,16))return false;
  unsigned exponent=bh[3];r->blockCount=le32(bh+4);
  r->totalUncompressed=le64(bh+8);
  if(exponent<14 || exponent>25 || r->blockCount==0 || r->blockCount>1000000){
    snprintf(err,errLen,"Unsupported NCZ block size/count (max 32 MiB per block)");return false;
  }
  r->blockSize=(uint64_t)1<<exponent;
  if(r->totalUncompressed!=uncompressedSize ||
      (r->totalUncompressed+r->blockSize-1)/r->blockSize!=r->blockCount){
    snprintf(err,errLen,"NCZ block size metadata does not match section lengths");return false;
  }
  uint64_t sizesEnd;
  if(!add_ok(payloadStart+24,(uint64_t)r->blockCount*4,&sizesEnd) || sizesEnd>fileEnd)return false;
  r->compressedSizes=calloc(r->blockCount,sizeof(uint32_t));
  r->blockBuf=malloc((size_t)r->blockSize);
  if(!r->compressedSizes || !r->blockBuf)return false;
  uint64_t total=0;
  for(uint32_t i=0;i<r->blockCount;i++){
    unsigned char v[4];if(!get(f,v,4))return false;
    uint64_t expected=i==r->blockCount-1 ? (r->totalUncompressed-r->blockSize*(r->blockCount-1)):r->blockSize;
    r->compressedSizes[i]=le32(v);
    if(!r->compressedSizes[i] || r->compressedSizes[i]>expected ||
       !add_ok(total,r->compressedSizes[i],&total))return false;
  }
  r->pos=sizesEnd;
  if(total>fileEnd-sizesEnd)return false;
  r->block=true;return true;
}
static bool reader_read(struct Reader *r, unsigned char *dest, size_t need){
  while(need){
    if(r->block){
      if(r->blockPos==r->blockAvail){
        if(r->blockIndex==r->blockCount)return false;
        uint64_t expected=r->blockIndex==r->blockCount-1 ?
          r->totalUncompressed-r->blockSize*(r->blockCount-1):r->blockSize;
        uint32_t srcLen=r->compressedSizes[r->blockIndex++];
        if(srcLen>r->end-r->pos || !at(r->f,r->pos))return false;
        if(srcLen==expected){
          if(!get(r->f,r->blockBuf,(size_t)expected))return false;
        }else{
          unsigned char *src=malloc(srcLen);if(!src)return false;
          bool ok=get(r->f,src,srcLen);
          size_t result=ok?ZSTD_decompress(r->blockBuf,(size_t)expected,src,srcLen):0;
          free(src);
          if(!ok || ZSTD_isError(result) || result!=expected)return false;
        }
        r->pos+=srcLen;r->blockPos=0;r->blockAvail=(size_t)expected;
      }
      size_t n=r->blockAvail-r->blockPos;if(n>need)n=need;
      memcpy(dest,r->blockBuf+r->blockPos,n);
      r->blockPos+=n;dest+=n;need-=n;
    }else{
      if(r->outPos==r->outSize){
        r->outPos=0;r->outSize=0;
        unsigned guard=0;
        while(r->outSize==0){
          if(r->inPos==r->inSize){
            if(r->pos>=r->end)return false;
            size_t take=(r->end-r->pos<CHUNK)?(size_t)(r->end-r->pos):CHUNK;
            if(!at(r->f,r->pos) || !get(r->f,r->inBuf,take))return false;
            r->pos+=take;r->inPos=0;r->inSize=take;
          }
          ZSTD_inBuffer in={r->inBuf,r->inSize,r->inPos};
          ZSTD_outBuffer out={r->outBuf,sizeof(r->outBuf),0};
          size_t result=ZSTD_decompressStream(r->ds,&out,&in);
          if(ZSTD_isError(result))return false;
          r->inPos=in.pos;r->outSize=out.pos;
          if(++guard>100000)return false;
        }
      }
      size_t n=r->outSize-r->outPos;if(n>need)n=need;
      memcpy(dest,r->outBuf+r->outPos,n);
      r->outPos+=n;dest+=n;need-=n;
    }
  }
  return true;
}

static bool section_info(FILE *f,uint64_t sourceStart,uint64_t compressedSize,
                         struct Section **outSections,uint32_t *outCount,
                         uint64_t *outUncompressedSize,uint64_t *outStreamStart){
  uint64_t fileEnd;
  if(!add_ok(sourceStart,compressedSize,&fileEnd) || compressedSize<0x4010)return false;
  unsigned char hdr[16];
  if(!at(f,sourceStart+0x4000) || !get(f,hdr,16) || memcmp(hdr,"NCZSECTN",8))return false;
  uint64_t count=le64(hdr+8);
  if(count==0 || count>MAX_SECTIONS || count>(compressedSize-0x4010)/64)return false;
  struct Section *sects=calloc((size_t)count,sizeof(*sects));if(!sects)return false;
  uint64_t previousEnd=0x4000, compressedDecodedSize=0;
  bool valid=true;
  for(uint32_t i=0;i<count;i++){
    unsigned char b[64];if(!get(f,b,64)){valid=false;break;}
    sects[i].off=le64(b);sects[i].size=le64(b+8);sects[i].crypto=le64(b+16);
    memcpy(sects[i].key,b+32,16);memcpy(sects[i].ctr,b+48,16);
    uint64_t end=0;
    if(!sects[i].size || !add_ok(sects[i].off,sects[i].size,&end) || end>INT64_MAX ||
       (i && sects[i].off!=previousEnd) ||
       (!i && sects[i].off>0x4000 && sects[i].off-0x4000>INT64_MAX/2) ||
       (i && sects[i].off<0x4000)) {valid=false;break;}
    if(!i && sects[i].off>0x4000) compressedDecodedSize=sects[i].off-0x4000;
    uint64_t start=sects[i].off<0x4000 ? 0x4000:sects[i].off;
    if(end>start && !add_ok(compressedDecodedSize,end-start,&compressedDecodedSize)){valid=false;break;}
    previousEnd=end;
  }
  uint64_t streamEnd=sourceStart+0x4010+count*64;
  if(!valid || streamEnd>fileEnd || compressedDecodedSize>INT64_MAX){free(sects);return false;}
  *outSections=sects;*outCount=(uint32_t)count;
  *outUncompressedSize=compressedDecodedSize;
  *outStreamStart=streamEnd;
  return true;
}

#ifdef __APPLE__
typedef CCCryptorRef AESContext;
static bool aes_start(AESContext *ctx,const unsigned char *key){
  return CCCryptorCreate(kCCEncrypt,kCCAlgorithmAES,kCCOptionECBMode,key,kCCKeySizeAES128,NULL,ctx)==kCCSuccess;
}
static bool aes_blocks(AESContext ctx,const unsigned char *in,unsigned char *out,size_t size){
  size_t written=0;
  return CCCryptorUpdate(ctx,in,size,out,size,&written)==kCCSuccess && written==size;
}
static void aes_close(AESContext ctx){CCCryptorRelease(ctx);}
#else
typedef EVP_CIPHER_CTX* AESContext;
static bool aes_start(AESContext *ctx,const unsigned char *key){
  *ctx=EVP_CIPHER_CTX_new();return *ctx &&
    EVP_EncryptInit_ex(*ctx,EVP_aes_128_ecb(),NULL,key,NULL)==1 &&
    EVP_CIPHER_CTX_set_padding(*ctx,0)==1;
}
static bool aes_blocks(AESContext ctx,const unsigned char *in,unsigned char *out,size_t size){
  int written=0;return EVP_EncryptUpdate(ctx,out,&written,in,(int)size)==1 && (size_t)written==size;
}
static void aes_close(AESContext ctx){EVP_CIPHER_CTX_free(ctx);}
#endif
static bool crypt_chunk(AESContext ctx, const unsigned char *prefix, uint64_t fileOffset,
                        unsigned char *buf,size_t len){
  unsigned char counters[CHUNK+32],stream[CHUNK+32];
  size_t skip=(size_t)(fileOffset&15);
  size_t blocks=(len+skip+15)/16;
  if(blocks*16>sizeof(counters))return false;
  uint64_t ctr=fileOffset>>4;
  for(size_t i=0;i<blocks;i++){
    memcpy(counters+16*i,prefix,8);
    uint64_t x=ctr+i;
    for(int j=15;j>=8;j--){counters[16*i+j]=(unsigned char)x;x>>=8;}
  }
  if(!aes_blocks(ctx,counters,stream,blocks*16))return false;
  for(size_t i=0;i<len;i++)buf[i]^=stream[skip+i];
  return true;
}
static bool decompress_ncz(FILE *in,FILE *out,uint64_t inStart,uint64_t inSize,
                           uint64_t expectedOutSize, uint64_t *progressWritten,
                           uint64_t total,nsz_progress_fn callback,void *ctx,
                           char *err,size_t errLen){
  struct Section *sections=NULL;uint32_t num=0;uint64_t decoded=0,payloadStart=0;
  struct Reader r;memset(&r,0,sizeof(r));
  bool ok=false;unsigned char buf[CHUNK];
  if(!section_info(in,inStart,inSize,&sections,&num,&decoded,&payloadStart)){
    snprintf(err,errLen,"Bad NCZ section metadata");goto done;
  }
  if(decoded+0x4000!=expectedOutSize){snprintf(err,errLen,"NCZ size mismatch");goto done;}
  if(!at(in,inStart) || !get(in,buf,0))goto done;
  /* Encrypted, incompressible first 0x4000 bytes of the NCA */
  unsigned char initial[0x4000];
  if(!get(in,initial,sizeof(initial)) || !put(out,initial,sizeof(initial)))goto done;
  *progressWritten+=sizeof(initial);
  uint64_t fileEnd=inStart+inSize;
  if(!reader_init(&r,in,payloadStart,fileEnd,decoded,err,errLen)){
    if(!err[0])snprintf(err,errLen,"Unable to initialize Zstandard decoder");
    goto done;
  }
  uint64_t cursor=0x4000;
  for(uint32_t s=0;s<num;s++){
    uint64_t start=sections[s].off;
    uint64_t end=start+sections[s].size;
    AESContext aes=NULL;
    if(start>cursor){
      uint64_t gap=start-cursor;
      while(gap){
        size_t n=gap>CHUNK?CHUNK:(size_t)gap;
        if(!reader_read(&r,buf,n) || !put(out,buf,n))goto done;
        gap-=n;cursor+=n;*progressWritten+=n;
      }
    }
    if(start<cursor)start=cursor;
    if(start>=end)continue;
    if(sections[s].crypto==3 || sections[s].crypto==4){
      if(!aes_start(&aes,sections[s].key))goto done;
    }else if(sections[s].crypto!=0 && sections[s].crypto!=1){
      snprintf(err,errLen,"Unsupported NCZ crypto type: %"PRIu64,sections[s].crypto);goto done;
    }
    uint64_t atOffset=start;
    bool sectionOK=true;
    while(atOffset<end){
      size_t n=end-atOffset>CHUNK?CHUNK:(size_t)(end-atOffset);
      if(!reader_read(&r,buf,n) ||
         (aes && !crypt_chunk(aes,sections[s].ctr,atOffset,buf,n)) || !put(out,buf,n)){
        sectionOK=false;break;
      }
      atOffset+=n;cursor+=n;*progressWritten+=n;
      if(callback && ((*progressWritten & ((2*1024*1024)-1))<n))callback(*progressWritten,total,ctx);
    }
    if(aes)aes_close(aes);
    if(!sectionOK)goto done;
  }
  ok=cursor==expectedOutSize;
  if(!ok)snprintf(err,errLen,"NCZ output length was incorrect");
 done:
  reader_close(&r);free(sections);
  if(!ok && !err[0])snprintf(err,errLen,"Truncated or invalid NCZ data");
  return ok;
}
int nsz_convert(const char *inputPath,const char *outputPath,
                nsz_progress_fn callback,void *ctx,char *err,size_t errLen){
  if(!err || errLen==0)return -1;
  err[0]=0;FILE *in=NULL,*out=NULL;
  unsigned char *header=NULL;struct Entry *entries=NULL;
  uint64_t inputLength=0,total=0,done=0;int result=-1;
  bool outputCreated=false;
  if(!inputPath || !outputPath){snprintf(err,errLen,"Missing file path");return -1;}
  if(strcmp(inputPath,outputPath)==0){snprintf(err,errLen,"Input and output paths must differ");return -1;}
  in=fopen(inputPath,"rb");if(!in){snprintf(err,errLen,"Cannot open NSZ input");goto cleanup;}
  if(fseeko(in,0,SEEK_END)!=0){snprintf(err,errLen,"Cannot inspect file length");goto cleanup;}
  off_t len=ftello(in);if(len<16){snprintf(err,errLen,"File is too small");goto cleanup;}
  inputLength=(uint64_t)len;
  unsigned char basic[16];
  if(!at(in,0)||!get(in,basic,16)||memcmp(basic,"PFS0",4)){
    snprintf(err,errLen,"Not an NSZ/PFS0 container");goto cleanup;
  }
  uint32_t count=le32(basic+4),strLen=le32(basic+8);
  uint64_t headerLen=16+(uint64_t)count*24+strLen;
  if(!count || count>MAX_FILES || headerLen>MAX_HEADER || headerLen>inputLength){
    snprintf(err,errLen,"Invalid NSZ header size/count");goto cleanup;
  }
  header=malloc((size_t)headerLen);entries=calloc(count,sizeof(*entries));
  if(!header||!entries){snprintf(err,errLen,"Out of memory");goto cleanup;}
  if(!at(in,0)||!get(in,header,(size_t)headerLen)){
    snprintf(err,errLen,"Could not read NSZ header");goto cleanup;
  }
  uint64_t inDataStart=headerLen, outOffset=0;
  for(uint32_t i=0;i<count;i++){
    unsigned char *e=header+16+(uint64_t)i*24;
    uint64_t rel=le64(e),size=le64(e+8);
    uint32_t no=le32(e+16);
    if(no>=strLen || !memchr(header+16+(uint64_t)count*24+no,0,strLen-no) ||
       !add_ok(inDataStart,rel,&entries[i].inOff) ||
       entries[i].inOff>inputLength || size>inputLength-entries[i].inOff){
      snprintf(err,errLen,"Invalid file entry in NSZ header");goto cleanup;
    }
    entries[i].inSize=size;entries[i].nameOffset=no;
    char *name=(char*)(header+16+(uint64_t)count*24+no);
    size_t n=strlen(name);
    entries[i].compressed=(n>=4 && strcmp(name+n-4,".ncz")==0);
    if(entries[i].compressed){
      struct Section *sections=NULL;uint32_t nsect=0;uint64_t decoded=0,payload=0;
      bool ok=section_info(in,entries[i].inOff,size,&sections,&nsect,&decoded,&payload);
      free(sections);
      if(!ok || !add_ok(decoded,0x4000,&entries[i].outSize)){
        snprintf(err,errLen,"Invalid NCZ metadata: %s",name);goto cleanup;
      }
      name[n-1]='a'; /* .ncz -> .nca; same-length filename */
    }else entries[i].outSize=size;
    put64(e,outOffset);put64(e+8,entries[i].outSize);
    if(!add_ok(outOffset,entries[i].outSize,&outOffset)||
       !add_ok(total,entries[i].outSize,&total) || total>INT64_MAX){
      snprintf(err,errLen,"Output file exceeds supported size");goto cleanup;
    }
  }
  int fd=open(outputPath,O_WRONLY|O_CREAT|O_EXCL,0600);
  if(fd<0){snprintf(err,errLen,"Cannot create NSP output (file exists, storage full, or permission denied)");goto cleanup;}
  outputCreated=true;out=fdopen(fd,"wb");
  if(!out){close(fd);snprintf(err,errLen,"Cannot open NSP output stream");goto cleanup;}
  if(!put(out,header,(size_t)headerLen)){snprintf(err,errLen,"Cannot write NSP header");goto cleanup;}
  unsigned char chunk[CHUNK];
  if(callback)callback(0,total,ctx);
  for(uint32_t i=0;i<count;i++){
    if(entries[i].compressed){
      if(!decompress_ncz(in,out,entries[i].inOff,entries[i].inSize,
                          entries[i].outSize,&done,total,callback,ctx,err,errLen))goto cleanup;
    }else{
      if(!at(in,entries[i].inOff)){
        snprintf(err,errLen,"Could not seek to container member");goto cleanup;
      }
      uint64_t left=entries[i].inSize;
      while(left){
        size_t take=left>CHUNK?CHUNK:(size_t)left;
        if(!get(in,chunk,take)||!put(out,chunk,take)){
          snprintf(err,errLen,"Read/write error or insufficient storage");goto cleanup;
        }
        left-=take;done+=take;
        if(callback && (done%(2*1024*1024)<take))callback(done,total,ctx);
      }
    }
    if(callback)callback(done,total,ctx);
  }
  if(fflush(out)!=0 || ferror(out)){snprintf(err,errLen,"Output write failed (possibly out of space)");goto cleanup;}
  result=0;
 cleanup:
  if(in)fclose(in);
  if(out && fclose(out)!=0 && result==0){result=-1;snprintf(err,errLen,"Failed to finalize NSP output");}
  if(result!=0 && outputCreated)remove(outputPath);
  free(header);free(entries);
  return result;
}
